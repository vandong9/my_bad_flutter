//
//  WelcomeViewController.swift
//  MyVIB_2.0
//
//  Created by ha van dong on 5/27/22.
//

import UIKit
import Lottie

struct WelcomeContent {
    var lottieFile: String? // first priority
    var lottieLink: String?
    var message: String
    var buttonTitle: String
    
    static var detault: WelcomeContent {
//        WelcomeContent(lottieFile: nil, lottieLink: AppAnimationFileManager.shared.animationFile?.lottieWelcome, message: "login_welcome_msg".localized(), buttonTitle: "login_welcome_button".localized())
        WelcomeContent(lottieFile: UserSettings.shared.theme == .ice ? "fz_intro_ice" : "fz_intro_fire", lottieLink: nil, message: "fz_intro_label".localized(), buttonTitle: "welcom_join_now".localized())
    }
}

class WelcomeViewController: BaseBottomPopupVC {
    // MARK: - Properties
    @IBOutlet weak var lottieContainerView: UIView!
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var confirmButton: VIBButton!
    
    var animation: AnimationView?
    
    var content: WelcomeContent = WelcomeContent.detault
    var onConfirmCallback: (() -> Void)?
    
    // MARK: - LifeCycle
    
    static func instance(content: WelcomeContent, onConfirmCallback: @escaping (() -> Void)) -> WelcomeViewController {
        let vc = VIBStoryboard.newViewControllerFromStoryboard(name: VIBStoryboard.authentication.rawValue, identifier: WelcomeViewController.mainID()) as! WelcomeViewController
        vc.content = content
        vc.onConfirmCallback = onConfirmCallback
        return vc
    }
    
    static func present(on: UIViewController, content: WelcomeContent, onConfirmCallback: @escaping (() -> Void)) {
        let vc = WelcomeViewController.instance(content: content, onConfirmCallback: onConfirmCallback)
        vc.height = AppUIConstant.kHeightBottomSheetCommon
        vc.topCornerRadius = AppUIConstant.kRadiusTopBottomPopup

        on.present(vc, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.layoutIfNeeded()
        setupUI()
        
        showData()
        
    }

    // MARK: - IBActions
    @IBAction func onConfirmButtonAction() {
        self.dismiss(animated: true)
        onConfirmCallback?()
    }
    
    // MARK: - Functions
    private func setupUI() {
        view.backgroundColor = AppColor.baseWhite
        messageLabel.font = AppFont.baseTitle2
        messageLabel.textColor = AppColor.baseGrey900
        lottieContainerView.backgroundColor = .clear
    }
    
    func showData() {
        messageLabel.text = content.message
        confirmButton.setTitle(content.buttonTitle, for: .normal)
        
        if let lottieFile = content.lottieFile {
            animation = .init(name: lottieFile)
            animation?.play()
        } else {
            if let url =  URL(string: content.lottieLink ?? "") {
                animation = .init(url: url) { [weak self] error in
                    guard error == nil else { return }
                    self?.animation?.play()
                }
            }
        }
        
        if let animation = animation {
            lottieContainerView.addSubview(animation)
            animation.frame = lottieContainerView.bounds
            animation.snp.makeConstraints { $0.edges.equalToSuperview() }
            animation.loopMode = .loop
            animation.contentMode = .scaleAspectFit
        }
    }
}
